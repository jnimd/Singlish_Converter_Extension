// si-sinhala-converter.js
document.addEventListener("DOMContentLoaded", function() {
  const singlishInput = document.getElementById('singlishInput');
  const sinhalaOutput = document.getElementById('sinhalaOutput');
  const singlishCharCount = document.getElementById('singlishCharCount');
  const sinhalaCharCount = document.getElementById('sinhalaCharCount');
  const copyUnicodeBtn = document.getElementById('copyUnicodeBtn');
  const shareBtn = document.getElementById('shareBtn');
  const clearBtn = document.querySelector('.action-btn:nth-child(3)');
  const exampleTags = document.querySelectorAll('.example-tag');
  const tabButtons = document.querySelectorAll('.tab-btn');
  const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
  const inputFormatDisplay = document.querySelector('#inputFormat .dropdown-toggle span');
  const outputFormatDisplay = document.querySelector('#outputFormat .dropdown-toggle span');
  const panels = document.querySelectorAll('.converter-panel');
  

  let currentInputFormat = 'Singlish';
  let currentOutputFormat = 'Unicode';

  const singlishMap = {
    // --- Vowels ---
    'aa': 'ආ', 'Aa': 'ඈ', 'AA': 'ඈ', 'ii': 'ඊ', 'uu': 'ඌ', 'ee': 'ඒ',
    'ai': 'ඓ', 'oo': 'ඕ', 'au': 'ඖ', 'ou': 'ඖ', 'a': 'අ', 'A': 'ඇ',
    'i': 'ඉ', 'u': 'උ', 'R': 'ඍ', 'Ru': 'ඎ', 'e': 'එ', 'o': 'ඔ',
    // --- Consonants ---
    'ka': 'ක', 'ga': 'ග', 'cha': 'ච', 'ja': 'ජ', 'Na': 'ණ', 'ta': 'ට', 'Da': 'ඩ',
    'na': 'න', 'pa': 'ප', 'ba': 'බ', 'ma': 'ම', 'ya': 'ය', 'ra': 'ර', 'la': 'ල',
    'La': 'ළ', 'wa': 'ව', 'va': 'ව', 'sa': 'ස', 'sha': 'ශ', 'Sa': 'ෂ', 'Sha': 'ෂ',
    'ha': 'හ', 'fa': 'ෆ', 'tha': 'ත', 'dha': 'ද', 'qa': 'ද',
    // --- Aspirated Consonants ---
    'kha': 'ඛ', 'gha': 'ඝ', 'chha': 'ඡ', 'Ta': 'ඨ', 'Dhha': 'ඪ', 'thha': 'ථ',
    'dhha': 'ධ', 'pha': 'ඵ', 'bha': 'භ',
    // --- Nasal and Other Special Characters ---
    'zga': 'ඟ', 'zja': 'ඦ', 'zda': 'ඬ', 'zdha': 'ඳ', 'zqa': 'ඳ', 'zha': 'ඥ',
    'zka': 'ඤ', 'Ba': 'ඹ', 'Lu': 'ළු',
    // --- Vowel Marks Combinations ---
    'kAA': 'කෑ', 'gAA': 'ගෑ', 'cAA': 'චෑ', 'jAA': 'ජෑ', 'tAA': 'ටෑ', 'DAA': 'ඩෑ', 'thAA': 'තෑ',
    'dhAA': 'දෑ', 'nAA': 'නෑ', 'NAA': 'ණෑ', 'pAA': 'පෑ', 'bAA': 'බෑ', 'mAA': 'මෑ', 'yAA': 'යෑ',
    'rAA': 'රෑ', 'lAA': 'ලෑ', 'LAA': 'ළෑ', 'wAA': 'වැ', 'vAA': 'වෑ', 'sAA': 'සෑ', 'shAA': 'ශෑ',
    'SAA': 'ෂෑ', 'hAA': 'හෑ', 'fAA': 'ෆෑ',
    'kAa': 'කෑ', 'gAa': 'ගෑ', 'cAa': 'චෑ', 'jAa': 'ජෑ', 'tAa': 'ටෑ', 'DAa': 'ඩෑ', 'thhAa': 'තෑ',
    'dhAa': 'දෑ', 'nAa': 'නෑ', 'NAa': 'ණෑ', 'pAa': 'පෑ', 'bAa': 'බෑ', 'mAa': 'මෑ', 'yAa': 'යෑ',
    'rAa': 'රෑ', 'lAa': 'ලෑ', 'LAa': 'ළෑ', 'wAa': 'වැ', 'vAa': 'වෑ', 'sAa': 'සෑ', 'shAa': 'ශෑ',
    'SAa': 'ෂෑ', 'hAa': 'හෑ', 'fAa': 'ෆෑ',
    'kii': 'කී', 'gii': 'ගී', 'chii': 'චී', 'jii': 'ජී', 'tii': 'ටී', 'dii': 'ඩී', 'thii': 'තී', 'dhii': 'දී',
    'nii': 'නී', 'Nii': 'ණී', 'pii': 'පී', 'bii': 'බී', 'mii': 'මී', 'yii': 'යී', 'rii': 'රී', 'lii': 'ලී',
    'Lii': 'ළී', 'wii': 'වී', 'vii': 'වී', 'sii': 'සී', 'shii': 'ශී', 'Sii': 'ෂී', 'hii': 'හී', 'fii': 'ෆී',
    'kaa': 'කා', 'gaa': 'ගා', 'chaa': 'චා', 'jaa': 'ජා', 'taa': 'ටා', 'daa': 'ඩා', 'thhaa': 'ථා',
    'dhha': 'ධා', 'naa': 'නා', 'Naa': 'ණා', 'paa': 'පා', 'baa': 'බා', 'maa': 'මා', 'yaa': 'යා', 
    'raa': 'රා', 'laa': 'ලා', 'Laa': 'ළා', 'waa': 'වා', 'vaa': 'වා', 'saa': 'සා', 'shaa': 'ශා',
    'Saa': 'ෂා', 'haa': 'හා', 'faa': 'ෆා', 'thaa':'තා',
    'kuu': 'කූ', 'guu': 'ගූ', 'chuu': 'චූ', 'juu': 'ජූ', 'tuu': 'ටූ', 'duu': 'ඩූ', 'thuu': 'තූ',
    'dhuu': 'දූ', 'nuu': 'නූ', 'Nuu': 'ණූ', 'puu': 'පූ', 'buu': 'බූ', 'muu': 'මූ', 'yuu': 'යූ',
    'ruu': 'රූ', 'luu': 'ලු', 'Luu': 'ළූ', 'wuu': 'වූ', 'vuu': 'වූ', 'suu': 'සු', 'shuu': 'ශූ',
    'Suu': 'ෂූ', 'huu': 'හූ', 'fuu': 'ෆු',
    'kru': 'කෘ', 'gru': 'ගෘ', 'chru': 'චෘ', 'jru': 'ජෘ', 'tru': 'ටෘ', 'dru': 'ඩෘ', 'thru': 'තෘ',
    'dhru': 'දෘ', 'nru': 'නෘ', 'Nru': 'ණෘ', 'pru': 'පෘ', 'bru': 'බෘ', 'mru': 'මෘ', 'yru': 'යෘ',
    'rru': 'රෘ', 'lru': 'ලෘ', 'Lru': 'ළෘ', 'wru': 'වෘ', 'vru': 'වෘ', 'sru': 'සෘ', 'shru': 'ශෘ',
    'Sru': 'ෂෘ', 'hru': 'හෘ', 'fru': 'ෆෘ',
    'kee': 'කේ', 'gee': 'ගේ', 'chee': 'චේ', 'jee': 'ජේ', 'tee': 'ටේ', 'dee': 'ඩේ', 'thee': 'තේ',
    'dhee': 'දේ', 'nee': 'නේ', 'Nee': 'ණේ', 'pee': 'පේ', 'bee': 'බේ', 'mee': 'මේ', 'yee': 'යේ',
    'ree': 'රේ', 'lee': 'ලේ', 'Lee': 'ළේ', 'wee': 'වේ', 'vee': 'වේ', 'see': 'සේ', 'shee': 'ශේ',
    'See': 'ෂේ', 'hee': 'හේ', 'fee': 'ෆේ',
    'koo': 'කෝ', 'goo': 'ගෝ', 'choo': 'චෝ', 'joo': 'ජෝ', 'too': 'ටෝ', 'doo': 'ඩෝ', 'thoo': 'තෝ',
    'dhoo': 'දෝ', 'noo': 'නෝ', 'Noo': 'ණෝ', 'poo': 'පෝ', 'boo': 'බෝ', 'moo': 'මෝ', 'yoo': 'යෝ',
    'roo': 'රෝ', 'loo': 'ලෝ', 'Loo': 'ළෝ', 'woo': 'වෝ', 'voo': 'වෝ', 'soo': 'සෝ', 'shoo': 'ශෝ',
    'Soo': 'ෂෝ', 'hoo': 'හෝ', 'foo': 'ෆෝ',
    'kau': 'කෞ', 'gau': 'ගෞ', 'chau': 'චෞ', 'jau': 'ජෞ', 'tau': 'ටෞ', 'dau': 'ඩෞ', 'thhau': 'ථෞ',
    'dhau': 'ධෞ', 'nau': 'නෞ', 'Nau': 'ණෞ', 'pau': 'පෞ', 'bau': 'බෞ', 'mau': 'මෞ', 'yau': 'යෞ',
    'rau': 'රෞ', 'lau': 'ලෞ', 'Lau': 'ළෞ', 'wau': 'වෞ', 'vau': 'වෞ', 'sau': 'සෞ', 'shau': 'ශෞ',
    'Sau': 'ෂෞ', 'hau': 'හෞ', 'fau': 'ෆෞ',
    'kax': 'කං', 'gazn': 'ගං', 'kazn': 'කං', 'gazn': 'ගං',
    'kaX': 'කඞ', 'gaX': 'ගඞ',
    'kya': 'ක්‍ය', 'gya': 'ග්‍ය', 'chya': 'ච්‍ය', 'jya': 'ජ්‍ය', 'tya': 'ට්‍ය', 'dya': 'ඩ්‍ය', 'thya': 'ත්‍ය',
    'dhya': 'ධ්‍ය', 'nya': 'න්‍ය', 'Nya': 'ණ්‍ය', 'pya': 'ප්‍ය', 'bya': 'බ්‍ය', 'mya': 'ම්‍ය', 'rya': 'ර්‍ය',
    'lya': 'ල්‍ය', 'Lya': 'ළ්‍ය', 'wya': 'ව්‍ය', 'vya': 'ව්‍ය', 'sya': 'ස්‍ය', 'shya': 'ශ්‍ය', 'Shya': 'ෂ්‍ය',
    'hya': 'භ්‍ය', 'fya': 'ෆ්‍ය',
    'kra': 'ක්‍ර', 'gra': 'ග්‍ර', 'chra': 'ච්‍ර', 'jra': 'ජ්‍ර', 'tra': 'ට්‍ර', 'dra': 'ඩ්‍ර', 'thra': 'ත්‍ර',
    'dhra': 'ධ්‍ර', 'nra': 'න්‍ර', 'Nra': 'ණ්‍ර', 'pra': 'ප්‍ර', 'bra': 'බ්‍ර', 'mra': 'ම්‍ර', 'yra': 'ය්‍ර',
    'lra': 'ල්‍ර', 'Lra': 'ළ්‍ර', 'wra': 'ව්‍ර', 'vra': 'ව්‍ර', 'sra': 'ස්‍ර', 'shra': 'ශ්‍ර', 'Shra': 'ෂ්‍ර',
    'hra': 'භ්‍ර', 'fra': 'ෆ්‍ර',
    // 2-character patterns (e.g., ka, ki, ku, ke, ko, kA, kH)
    'kA': 'කැ', 'gA': 'ගැ', 'cA': 'චැ', 'jA': 'ජැ', 'tA': 'ටැ', 'dA': 'ඩැ', 'thA': 'තැ', 'dhA': 'දැ',
    'nA': 'නැ', 'NA': 'ණැ', 'pA': 'පැ', 'bA': 'බැ', 'mA': 'මැ', 'yA': 'යැ', 'rA': 'රැ', 'lA': 'ලැ',
    'LA': 'ළැ', 'wA': 'වැ', 'vA': 'වැ', 'sA': 'සැ', 'shA': 'ශැ', 'SA': 'ෂැ', 'hA': 'හැ', 'fA': 'ෆැ',
    'ki': 'කි', 'gi': 'ගි', 'chi': 'චි', 'ji': 'ජි', 'ti': 'ටි', 'di': 'ඩි', 'thi': 'ති', 'dhi': 'දි',
    'ni': 'නි', 'Ni': 'ණි', 'pi': 'පි', 'bi': 'බි', 'mi': 'මි', 'yi': 'යි', 'ri': 'රි', 'li': 'ලි',
    'Li': 'ළි', 'wi': 'වි', 'vi': 'වි', 'si': 'සි', 'shi': 'ශි', 'Si': 'ෂි', 'hi': 'හි', 'fi': 'ෆි',
    'ku': 'කු', 'gu': 'ගු', 'chu': 'චු', 'ju': 'ජු', 'tu': 'ටු', 'du': 'ඩු', 'thu': 'තු', 'dhu': 'දු',
    'nu': 'නු', 'Nu': 'ණූ', 'pu': 'පු', 'bu': 'බු', 'mu': 'මු', 'yu': 'යු', 'ru': 'රු', 'lu': 'ලු',
    'Lu': 'ළු', 'wu': 'වු', 'vu': 'වු', 'su': 'සු', 'shu': 'ශු', 'Su': 'ෂු', 'hu': 'හු', 'fu': 'ෆු',
    'ke': 'කෙ', 'ge': 'ගෙ', 'che': 'චෙ', 'je': 'ජෙ', 'te': 'ටෙ', 'de': 'ඩෙ', 'the': 'තෙ', 'dhe': 'දෙ',
    'ne': 'නෙ', 'Ne': 'ණෙ', 'pe': 'පෙ', 'be': 'බෙ', 'me': 'මෙ', 'ye': 'යෙ', 're': 'රෙ', 'le': 'ලෙ',
    'Le': 'ළෙ', 'we': 'වෙ', 've': 'වෙ', 'se': 'සෙ', 'she': 'ශෙ', 'Se': 'ෂෙ', 'he': 'හෙ', 'fe': 'ෆෙ',
    'ko': 'කො', 'go': 'ගො', 'cho': 'චො', 'jo': 'ජො', 'to': 'ටො', 'do': 'ඩො', 'tho': 'තො', 'dho': 'දො',
    'no': 'නො', 'No': 'ණො', 'po': 'පො', 'bo': 'බො', 'mo': 'මො', 'yo': 'යො', 'ro': 'රො', 'lo': 'ලො',
    'Lo': 'ළො', 'wo': 'වො', 'vo': 'වො', 'so': 'සො', 'sho': 'ශො', 'So': 'ෂො', 'ho': 'හො', 'fo': 'ෆො',
    'kH': 'කඃ', 'gH': 'ගඃ',
    // 1-character pattern (k)
    'k': 'ක්', 'g': 'ග්', 'c': 'ච්', 'j': 'ජ්', 't': 'ට්', 'd': 'ඩ්', 'th': 'ත්', 'dh': 'ද්',
    'n': 'න්', 'N': 'ණ්', 'p': 'ප්', 'b': 'බ්', 'm': 'ම්', 'y': 'ය්', 'r': 'ර්', 'l': 'ල්',
    'L': 'ළ්', 'w': 'ව්', 'v': 'ව්', 's': 'ස්', 'S': 'ෂ්', 'h': 'හ්', 'f': 'ෆ්',
    // --- Punctuation, Numbers, and Other Symbols ---
    '.': '.', ',': ',', '?': '?', '!': '!', ' ': ' ', '(': '(', ')': ')', '[': '[', ']': ']',
    '{': '{', '}': '}', ':': ':', ';': ';', '-': '-', '_': '_', '/': '/', '\\': '\\', '=': '=',
    '+': '+', '&': '&', '*': '*', '%': '%', '$': '$', '@': '@', '#': '#', '~': '~', '`': '`',
    "'": "'", '"': '"', '0': '0', '1': '1', '2': '2', '3': '3', '4': '4', '5': '5', '6': '6',
    '7': '7', '8': '8', '9': '9',
  };

  const reverseSinglishMap = {};
  for (const singlish in singlishMap) {
    const unicode = singlishMap[singlish];
    if (unicode.length > 0) {
      if (!reverseSinglishMap[unicode] || singlish.length > reverseSinglishMap[unicode].length) {
        reverseSinglishMap[unicode] = singlish;
      }
    }
  }

  // --- Abhaya සහ ISI ෆොන්ට් සඳහා mappings ---
  const abhayaMap = {
    'අ': 'A', 'ආ': 'B', 'ඇ': 'C', 'ඈ': 'D', 'ඉ': 'E', 'ඊ': 'F', 'උ': 'G', 'ඌ': 'H',
    'එ': 'I', 'ඒ': 'J', 'ඓ': 'K', 'ඔ': 'L', 'ඕ': 'M', 'ඖ': 'N', 'ක': 's', 'ඛ': 'S',
    'ග': 'g', 'ඝ': 'G', 'ඟ': 'x', 'ච': 'c', 'ඡ': 'C', 'ජ': 'j', 'ඣ': 'J', 'ඤ': '¥',
    'ඥ': '§', 'ට': 't', 'ඨ': 'T', 'ඩ': 'f', 'ඪ': 'F', 'ණ': '¨', 'ඬ': '´',
    'ත': 'q', 'ථ': 'Q', 'ද': 'd', 'ධ': 'D', 'න': 'n', 'ඳ': 'µ',
    'ප': 'p', 'ඵ': 'P', 'බ': 'b', 'භ': 'B', 'ම': 'm', 'ඹ': '»',
    'ය': 'y', 'ර': 'r', 'ල': 'l', 'ව': 'v', 'ශ': 'u', 'ෂ': 'U',
    'ස': 's', 'හ': 'h', 'ළ': 'o', 'ෆ': 'w', 'ඦ': 'W', 'ඣ': 'J',
    'ා': 'f', 'ැ': 'F', 'ෑ': 'e', 'ි': 'i', 'ී': 'I', 'ු': 'u', 'ූ': 'U',
    'ෙ': 'e', 'ේ': 'E', 'ෛ': 'Y', 'ො': 'o', 'ෝ': 'O', 'ෞ': 'W',
    'ං': 'x', 'ඃ': 'X', 'ෲ': 'e', 'ෘ': 'R', 'ෟ': 'ç', '්': 'a',
    '1': '1', '2': '2', '3': '3', '4': '4', '5': '5', '6': '6', '7': '7', '8': '8', '9': '9', '0': '0',
    ' ': ' ', '.': '.', ',': ',', ';': ';', ':': ':', '?': '?', '!': '!', '(': '(', ')': ')',
  };

  const isiMap = {
    'අ': 'a', 'ආ': 'A', 'ඇ': 'æ', 'ඈ': 'Æ', 'ඉ': 'i', 'ඊ': 'I', 'උ': 'u', 'ඌ': 'U',
    'එ': 'e', 'ඒ': 'E', 'ඓ': 'Y', 'ඔ': 'o', 'ඕ': 'O', 'ඖ': 'W',
    'ක': 'k', 'ඛ': 'K', 'ග': 'g', 'ඝ': 'G', 'ඟ': 'x', 'ච': 'c',
    'ඡ': 'C', 'ජ': 'j', 'ඣ': 'J', 'ඤ': 'V', 'ඥ': 'v', 'ට': 't',
    'ඨ': 'T', 'ඩ': 'd', 'ඪ': 'D', 'ණ': 'N', 'ඬ': 'z',
    'ත': 'p', 'ථ': 'P', 'ද': 'b', 'ධ': 'B', 'න': 'n', 'ඳ': 'm',
    'ප': 'f', 'ඵ': 'F', 'බ': 'w', 'භ': 'W', 'ම': 'M', 'ඹ': 'j',
    'ය': 'y', 'ර': 'r', 'ල': 'l', 'ව': 'v', 'ශ': 'S', 'ෂ': 'X',
    'ස': 's', 'හ': 'h', 'ළ': 'L', 'ෆ': 'Z', 'ඦ': 'J', 'ඣ': 'j',
    'ා': 'f', 'ැ': 'F', 'ෑ': 'E', 'ි': 'i', 'ී': 'I', 'ු': 'u', 'ූ': 'U',
    'ෙ': 'e', 'ේ': 'E', 'ෛ': 'Y', 'ො': 'o', 'ෝ': 'O', 'ෞ': 'W',
    'ං': 'x', 'ඃ': 'H', 'ෲ': 'o', 'ෘ': 'R', 'ෟ': 'P', '්': 'q',
    '1': '1', '2': '2', '3': '3', '4': '4', '5': '5', '6': '6', '7': '7', '8': '8', '9': '9', '0': '0',
    ' ': ' ', '.': '.', ',': ',', ';': ';', ':': ':', '?': '?', '!': '!', '(': '(', ')': ')',
  };

  // Unicode to Non-Unicode mappings
  const unicodeToAbhayaMap = abhayaMap;
  const unicodeToIsiMap = isiMap;

  // Non-Unicode to Unicode mappings
  const abhayaToUnicodeMap = Object.entries(unicodeToAbhayaMap).reduce((acc, [key, value]) => {
    acc[value] = key;
    return acc;
  }, {});

  const isiToUnicodeMap = Object.entries(unicodeToIsiMap).reduce((acc, [key, value]) => {
    acc[value] = key;
    return acc;
  }, {});

  // පරිවර්තන ෆන්ක්ෂන්ස්
  const transliterateSinglishToUnicode = (text) => {
    const sortedKeys = Object.keys(singlishMap).sort((a, b) => b.length - a.length);
    let result = '';
    let i = 0;
    while (i < text.length) {
      let matched = false;
      for (const key of sortedKeys) {
        if (text.startsWith(key, i)) {
          result += singlishMap[key];
          i += key.length;
          matched = true;
          break;
        }
      }
      if (!matched) {
        result += text[i];
        i++;
      }
    }
    return result;
  };

  const transliterateUnicodeToSinglish = (text) => {
    const sortedKeys = Object.keys(reverseSinglishMap).sort((a, b) => b.length - a.length);
    let result = '';
    let i = 0;
    while (i < text.length) {
      let matched = false;
      for (const key of sortedKeys) {
        if (text.startsWith(key, i)) {
          result += reverseSinglishMap[key];
          i += key.length;
          matched = true;
          break;
        }
      }
      if (!matched) {
        result += text[i];
        i++;
      }
    }
    return result;
  };

  const transliterate = (text, map) => {
    let result = '';
    for (let char of text) {
      result += map[char] || char;
    }
    return result;
  };

  const performConversion = () => {
    const inputText = singlishInput.value;
    let translatedText = '';

    if (currentInputFormat === 'Singlish' && currentOutputFormat === 'Unicode') {
      translatedText = transliterateSinglishToUnicode(inputText);
    } else if (currentInputFormat === 'Unicode' && currentOutputFormat === 'Singlish') {
      translatedText = transliterateUnicodeToSinglish(inputText);
    } else if (currentInputFormat === 'Unicode' && currentOutputFormat === 'FM Abhaya') {
      translatedText = transliterate(inputText, unicodeToAbhayaMap);
    } else if (currentInputFormat === 'FM Abhaya' && currentOutputFormat === 'Unicode') {
      translatedText = transliterate(inputText, abhayaToUnicodeMap);
    } else if (currentInputFormat === 'Unicode' && currentOutputFormat === 'ISI') {
      translatedText = transliterate(inputText, unicodeToIsiMap);
    } else if (currentInputFormat === 'ISI' && currentOutputFormat === 'Unicode') {
      translatedText = transliterate(inputText, isiToUnicodeMap);
    } else {
      translatedText = inputText;
    }

    sinhalaOutput.value = translatedText;
    updateCharCounts();
  };

  const updateCharCounts = () => {
    singlishCharCount.textContent = singlishInput.value.length;
    sinhalaCharCount.textContent = sinhalaOutput.value.length;
  };

  singlishInput.addEventListener('input', performConversion);

  // Input Format Options
  document.querySelectorAll('#inputFormat .dropdown-menu-small a').forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      const format = this.textContent.trim();
      currentInputFormat = format;
      inputFormatDisplay.textContent = format;
      singlishInput.placeholder = `Type in ${format}...`;
      performConversion();
    });
  });

  // Menu Toggle Logic
const menuToggleBtn = document.querySelector('.menu-toggle-btn');
const mainMenu = document.getElementById('mainMenu');

if (menuToggleBtn && mainMenu) {
    menuToggleBtn.addEventListener('click', (e) => {
        // Event එකේ propagation එක නවත්වනවා. මේක වැදගත්.
        e.stopPropagation(); 
        
        // මේකෙන් display: none නම් block කරනවා, block නම් none කරනවා
        if (mainMenu.style.display === 'block') {
            mainMenu.style.display = 'none';
        } else {
            mainMenu.style.display = 'block';
        }
    });

    // Browser එකේ වෙන තැනක click කලොත් menu එක close කරන්න
    document.addEventListener('click', (event) => {
        // Menu එක විවෘත වෙලා තියෙනවා නම් සහ click කළේ Button එකට හෝ Menu එකට නෙවෙයි නම්
        if (mainMenu.style.display === 'block' && 
            !menuToggleBtn.contains(event.target) && 
            !mainMenu.contains(event.target)) {
            
            mainMenu.style.display = 'none'; // Menu එක වසනවා
        }
    });
}

  // --- HELP MODAL LOGIC (උදව් Pop-up එක සඳහා) ---
  const helpLink = document.getElementById('helpLink');
  const helpModal = document.getElementById('helpModal');
  const closeHelpModalBtn = document.getElementById('closeHelpModal');
   

  // Function to show the modal
  function showHelpModal(event) {
    if (event) event.preventDefault(); // Default link ක්‍රියාව නවත්වයි
    
    // Modal එක පෙන්වයි
    if (helpModal) {
      helpModal.style.display = 'flex'; 
    }
    
    // Help link එක click කළ විට menu dropdown එක වසයි
    if (mainMenu && mainMenu.classList.contains('show')) {
        mainMenu.classList.remove('show');
    }
  }

  // Function to hide the modal
  function hideHelpModal() {
    if (helpModal) {
      helpModal.style.display = 'none';
    }
  }

  // 1. Help link එක click කළ විට modal එක පෙන්වයි
  if (helpLink) {
    helpLink.addEventListener('click', showHelpModal);
  }

  // 2. Close button එක click කළ විට modal එක සඟවයි
  if (closeHelpModalBtn) {
    closeHelpModalBtn.addEventListener('click', hideHelpModal);
  }

  // 3. Modal එකේ පිටත (අඳුරු පසුබිම) click කළ විට modal එක සඟවයි
  if (helpModal) {
    helpModal.addEventListener('click', function(event) {
      if (event.target === helpModal) {
        hideHelpModal();
      }
    });
  }

 // Closes the DOMContentLoaded listener (මෙහිදී ඔබගේ file එකේ අවසාන වරහන වසා දැමිය යුතුය)

// popup.js file එකේ DOMContentLoaded ඇතුළත

// --- New Modal Elements ---

const closeHelpModal = document.getElementById('closeHelpModal'); // Help close button

const keyMapModal = document.getElementById('keyMapModal'); // New Modal div
const closeKeyMapModal = document.getElementById('closeKeyMapModal'); // New Modal close button
const keyMapLink = document.getElementById('keyMapLink'); // Menu link to open

// --- 1. Help Modal Logic (පරණ Logic එක නිවැරදි කරමු) ---


if (helpLink && helpModal) {
    helpLink.addEventListener('click', function(event) {
        event.preventDefault();
        // Modal එක display: flex වලින් open කරයි
        helpModal.style.display = 'flex'; 
        // Menu එක close කරයි
        document.getElementById('mainMenu').classList.remove('show'); 
    });
}
if (closeHelpModal && helpModal) {
    closeHelpModal.addEventListener('click', function() {
        // Modal එක display: none වලින් close කරයි
        helpModal.style.display = 'none'; 
    });
}

// --- 2. Key Map Modal Logic (අලුතින් එකතු කළ යුතුයි) ---
if (keyMapLink && keyMapModal) {
    keyMapLink.addEventListener('click', function(event) {
        event.preventDefault();
        // Modal එක display: flex වලින් open කරයි
        keyMapModal.style.display = 'flex'; 
        // Menu එක close කරයි
        document.getElementById('mainMenu').classList.remove('show'); 
    });
}
if (closeKeyMapModal && keyMapModal) {
    closeKeyMapModal.addEventListener('click', function() {
        // Modal එක display: none වලින් close කරයි
        keyMapModal.style.display = 'none'; 
    });
}
 
    document.addEventListener("DOMContentLoaded", function() {
  const helpLink = document.getElementById('helpLink'); 
  const keyMapLink = document.getElementById('keyMapLink');
  const helpPanel = document.getElementById('help-tab'); 
  const mainPanel = document.getElementById('converter-tab'); 
  const closeHelpBtn = document.getElementById('closeHelpBtn');
  const mainMenu = document.getElementById('mainMenu');
  const menuToggleBtn = document.querySelector('.menu-toggle-btn');

  // Toggle menu
  if (menuToggleBtn && mainMenu) {
    menuToggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (mainMenu.style.display === 'block') {
        mainMenu.style.display = 'none';
      } else {
        mainMenu.style.display = 'block';
      }
    });
    document.addEventListener('click', (event) => {
      if (mainMenu.style.display === 'block' && 
          !menuToggleBtn.contains(event.target) && 
          !mainMenu.contains(event.target)) {
        mainMenu.style.display = 'none';
      }
    });
  }

  // Show panel helper
  function showPanel(panelToShow) {
    if (mainPanel) mainPanel.style.display = 'none'; 
    if (helpPanel) helpPanel.style.display = 'none';
    if (panelToShow) panelToShow.style.display = 'block'; 
  }

  // Help link click
  if (helpLink && helpPanel) {
    helpLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (mainMenu) mainMenu.style.display = 'none'; 
      showPanel(helpPanel);
    });
  }

  // Key map link (temporarily same as help)
  if (keyMapLink && helpPanel) {
    keyMapLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (mainMenu) mainMenu.style.display = 'none'; 
      showPanel(helpPanel);
    });
  }

  // Close Help
  if (closeHelpBtn && helpPanel) {
    closeHelpBtn.addEventListener('click', () => {
      helpPanel.style.display = 'none';
      if (mainPanel) mainPanel.style.display = 'block';
    });
  }
});


  // Output Format Options
  document.querySelectorAll('#outputFormat .dropdown-menu-small a').forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      const format = this.textContent.trim();
      currentOutputFormat = format;
      outputFormatDisplay.textContent = format;
      performConversion();
    });
  });

  // Other functionalities
  copyUnicodeBtn.addEventListener('click', function() {
    if (sinhalaOutput.value.length > 0) {
      navigator.clipboard.writeText(sinhalaOutput.value)
        .then(() => {
          alert('Text copied to clipboard!');
        })
        .catch(err => {
          console.error('Failed to copy text: ', err);
          sinhalaOutput.select();
          document.execCommand('copy');
          alert('Text copied to clipboard! (Fallback)');
        });
    } else {
      alert('There is no text to copy.');
    }
  });

  shareBtn.addEventListener('click', function() {
    if (sinhalaOutput.value.length > 0) {
      if (navigator.share) {
        navigator.share({
            title: 'Sinhala Converter',
            text: sinhalaOutput.value,
            url: window.location.href
          })
          .then(() => console.log('Successfully shared'))
          .catch((error) => console.log('Error sharing', error));
      } else {
        alert('Web Share API is not supported in your browser.');
      }
    } else {
      alert('There is no text to share.');
    }
  });

  clearBtn.addEventListener('click', function() {
    singlishInput.value = '';
    sinhalaOutput.value = '';
    updateCharCounts();
  });

  exampleTags.forEach(tag => {
    tag.addEventListener('click', function() {
      singlishInput.value = this.dataset.text;
      performConversion();
    });
  });

  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      document.querySelectorAll('.converter-panel').forEach(panel => panel.style.display = 'none');
      document.getElementById(this.dataset.tab + '-tab').style.display = 'flex';
    });
  });

  dropdownToggles.forEach(toggle => {
    toggle.addEventListener('click', function(event) {
      event.stopPropagation();
      const dropdownMenu = this.closest('.dropdown-action').querySelector('.dropdown-menu-small');
      dropdownMenu.classList.toggle('show');
    });
  });

  document.addEventListener('click', function(event) {
    dropdownToggles.forEach(toggle => {
      const dropdownMenu = toggle.closest('.dropdown-action').querySelector('.dropdown-menu-small');
      if (dropdownMenu && dropdownMenu.classList.contains('show') && !toggle.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.classList.remove('show');
      }
    });
  });
  


    // Clear function
    clearButton.addEventListener('click', () => {
        textarea.value = '';
    });

    // Copy function
    copyButton.addEventListener('click', () => {
        textarea.select();
        document.execCommand('copy');
    });

    // Share function
    shareButton.addEventListener('click', () => {
        if (navigator.share) {
            navigator.share({
                title: 'Sinhala Converted Text',
                text: textarea.value
            }).then(() => {
                console.log('Successfully shared');
            }).catch((error) => {
                console.error('Sharing failed', error);
            });
        } else {
            // Web Share API support නැති browsers වලට මේ message එක පෙන්වයි
            alert('Sharing is not supported on this browser. Please use the Copy button instead.');
        }
    });

   

});
   
